<ul class="item-price-wrap hide-on-list">
	<?php echo houzez_listing_price_v1(); ?>
</ul>