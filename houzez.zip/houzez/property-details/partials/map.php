<div class="map-wrap">
	<div id="houzez-single-listing-map"></div>	
</div>