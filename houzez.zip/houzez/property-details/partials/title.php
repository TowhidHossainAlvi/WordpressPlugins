<div class="page-title">
	<h1><?php the_title(); ?></h1>
</div><!-- page-title -->