<?php

// Exit if accessed directly
defined('ABSPATH') || exit;

/**
 * WordPress Custom Object Controller Interface
 *
 * @package RightPress
 * @author RightPress
 */
interface RightPress_WP_Custom_Object_Controller_Interface
{





}
