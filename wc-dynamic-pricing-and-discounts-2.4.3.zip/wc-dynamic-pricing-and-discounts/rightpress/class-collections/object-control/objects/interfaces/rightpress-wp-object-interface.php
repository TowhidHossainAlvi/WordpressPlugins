<?php

// Exit if accessed directly
defined('ABSPATH') || exit;

/**
 * WordPress Object Interface
 *
 * @package RightPress
 * @author RightPress
 */
interface RightPress_WP_Object_Interface
{





}
