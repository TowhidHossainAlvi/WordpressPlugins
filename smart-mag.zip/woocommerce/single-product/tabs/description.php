<?php
/**
 * Description tab
 *
 * This template overrides woocommerce/templates/single-product/tabs/description.php.
 *
 * @see 	    http://docs.woothemes.com/document/template-structure/
 * @version     2.0.0
 */

?>

<div class="post-content">
	<?php the_content(); ?>
</div>