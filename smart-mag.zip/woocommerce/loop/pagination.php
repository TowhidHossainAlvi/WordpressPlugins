<?php 
/**
 * Pagination - Show numbered pagination for catalog pages.
 * 
 * @version     3.3.1
 */
?>
	<div class="main-pagination pagination-numbers">
		<?php echo Bunyad::posts()->paginate(); ?>
	</div>